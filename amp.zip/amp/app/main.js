
var React = require('react')
var Main = require('./src')
var templates = require('../templates/body.jade');

console.log(templates());
React.render(<Main/>, document.body);

console.log('Application is loaded!');
console.log('hello as')