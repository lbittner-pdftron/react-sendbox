var app = require('ampersand-app');
var Router = require('ampersand-router');
var HomePage = require('./pages/home');

var InfoPage = require('./pages/info');



module.exports = Router.extend({
    routes: {
        '': 'home',
        ':route:info': 'info',
        '(*path)': 'catchAll'
    },

    // ------- ROUTE HANDLERS ---------
    home: function () {
        app.trigger('page', new HomePage({
            model: app.me
        }));
    },


    info: function () {
        app.trigger('page', new InfoPage({
            model: app.me
        }));
    },

    catchAll: function () {
        this.redirectTo('');
    }
});
