var PageView = require('./base');
var templatesPagesHome = require('../../templates/pages/home.jade');

module.exports = PageView.extend({
    pageTitle: 'home',
    template: templatesPagesHome
});
