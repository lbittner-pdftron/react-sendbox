var PageView = require('./base');
var templatesPagesInfo = require('../../templates/pages/info.jade');

module.exports = PageView.extend({
    pageTitle: 'more info',
    template: templatesPagesInfo
});
